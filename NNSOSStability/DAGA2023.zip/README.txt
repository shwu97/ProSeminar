﻿DAGA
Hinweise zur Erstellung des Manuskripts:



- Windows: 
Bitte benutzen sie die Vorlage template_daga.tex, um Ihr Manuskript zu erstellen.


- Linux/OS X: 
Je nach Kodierungseinstellungen können Sie zwischen template_daga.tex (ANSI/latin1) oder template_daga_utf8.tex (utf8) wählen.



Erstellung mittels LaTeX:


Sowohl LaTeX als auch pdfLaTeX können genutzt werden, um das Manuskript zu erstellen. 
Bitte beachten sie auch die im Template angegebenen Hinweise.
